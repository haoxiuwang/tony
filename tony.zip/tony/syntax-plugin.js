const fs = require('fs');

module.exports = {
  name: 'tony-syntax-sugar',
  setup(build) {
    build.onLoad({ filter: /\.js$/ }, async (args) => {
      let source = await fs.promises.readFile(args.path, 'utf8');
      const transformed = source.replace(/await (\w+)\((.*?)\)!/g, 'if (!(await $1($2))) return;');
      return { contents: transformed, loader: 'js' };
    });
  }
}

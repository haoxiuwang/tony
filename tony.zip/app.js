import http from "http";
import { enhanceRequest, enhanceResponse } from "./tony/helpers.js";
import { handleError } from "./tony/error.js";

// 手动引入中间件和路由（按顺序执行）
import log from "./middlewares/log.js";
import cookies from "./middlewares/cookies.js";
import _home from "./routers/_home.js";
import _error from "./routers/_error.js";

http.createServer(async (req, res) => {
  try {
    enhanceRequest(req);
    enhanceResponse(res);

    await log(req, res)!;
    await cookies(req, res)!;

    await _home(req, res)!;
    await _error(req, res)!;

  } catch (err) {
    handleError(err, res);
  }
}).listen(3000, () => {
  console.log("Tony server running at http://localhost:3000");
});
